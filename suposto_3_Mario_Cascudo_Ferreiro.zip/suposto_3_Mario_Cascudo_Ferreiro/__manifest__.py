{
    'name':'Menganitos Jardineria Heredado',
    'description':'Modulo realizdo en el supuesto 3 donde se hace uso de la herencia',
    'author':'Mario Cascudo',
    'data':[
        'Views/vista.xml'
    ],
    'depends':['suposto_2_Mario_Cascudo_Ferreiro'],
    'application':False
}